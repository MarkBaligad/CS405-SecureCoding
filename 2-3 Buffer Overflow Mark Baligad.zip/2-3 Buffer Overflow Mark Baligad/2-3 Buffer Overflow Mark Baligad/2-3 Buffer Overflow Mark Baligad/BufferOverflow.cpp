// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <limits>

int main() {
    const std::string account_number = "CharlieBrown42";
    char user_input[20]{};  // zero-init

    std::cout << "Enter a value: ";

    // Read at most sizeof(user_input)-1 characters; writes a '\0' for you
    std::cin.getline(user_input, sizeof(user_input));

    if (std::cin.fail() && !std::cin.eof()) {
        // The line was longer than the buffer; clear and discard the rest
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Warning: Input exceeded buffer size. Extra characters were ignored.\n";
    }

    std::cout << "You entered: " << user_input << "\n";
    std::cout << "Account Number = " << account_number << "\n";
}
